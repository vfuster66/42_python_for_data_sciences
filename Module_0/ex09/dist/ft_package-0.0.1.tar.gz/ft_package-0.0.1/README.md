# ft_package

A simple Python package for counting elements in a list.
